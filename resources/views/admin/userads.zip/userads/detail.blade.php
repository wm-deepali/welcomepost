@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Job Ads</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Job Ads</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
	@if (session('success'))
	<div class="card-body">
	<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5>{{ Session::get('success') }}</h5>
	<?php Session::forget('success');?>
	</div>
    </div>
	@endif
	
	@if ($errors->any())
	<div class="card-body">
	<div class="alert alert-danger alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

	@foreach ($errors->all() as $error)
	<p>{{ $error }}</p>
	@endforeach

	</div>


	</div>

	@endif
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit Details</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="{{url('post-edit-job-ads')}}" role="form" id="quickForm" method="post" enctype="multipart/form-data">
                <div class="card-body">
				
				
				  
				  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Salary Period</label>
                    <input type="text" name="salary_period" class="form-control" value="{{$info->salary_period}}">
                    <input type="hidden" name="id" class="form-control" value="{{$info->id}}">
                  </div>
				  @csrf
				  
				  
				   <div class="form-group">
                    <label for="exampleInputEmail1">Position Type</label>
                    <input type="text" name="position_type" class="form-control" value="{{$info->position_type}}">
                   </div>
				   
				   <div class="form-group">
                    <label for="exampleInputEmail1">Salary From</label>
                    <input type="text" name="salary_from" class="form-control" value="{{$info->salary_from}}">
                   </div>
				   
				   <div class="form-group">
                    <label for="exampleInputEmail1">Salary To</label>
                    <input type="text" name="salary_to" class="form-control" value="{{$info->salary_to}}">
                   </div>
				   
				   <div class="form-group">
                    <label for="exampleInputEmail1">Ad Title</label>
                    <input type="text" name="ad_title" class="form-control" value="{{$info->ad_title}}">
                   </div>
				   
				   <div class="form-group">
                    <label for="exampleInputEmail1">Ad Type</label>
                    <input type="text" name="ad_type" class="form-control" value="{{$info->ad_type}}">
                   </div>
				   
				   <div class="form-group">
                    <label for="exampleInputEmail1">Description</label>
                    <input type="text" name="description" class="form-control" value="{{$info->description}}">
                   </div>
				  
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  
 
  @endsection